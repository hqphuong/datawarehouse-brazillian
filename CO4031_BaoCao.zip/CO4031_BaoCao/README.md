# Specialized Project — LaTeX documents

Each document is a standalone LaTeX project in `projects/<name>/`. A project folder holds
everything it needs (`main.tex`, sections, `Resources/` images, `.bib`), so it can also be
zipped and uploaded to Overleaf on its own (set compiler to **XeLaTeX**).

```
.
├── docker/Dockerfile        # shared TeX Live toolchain (XeLaTeX + biber + Vietnamese)
├── templates/report/        # skeleton copied by `make new`
├── projects/
│   └── overall-survey/      # one standalone document
│       ├── main.tex
│       ├── .latexmkrc       # XeLaTeX, output to build/
│       ├── Resources/       # images
│       └── build/           # generated, git-ignored
├── Makefile
└── .vscode/settings.json    # LaTeX Workshop, compiles via Docker
```

## Requirements

- Docker Desktop running
- VSCode + LaTeX Workshop (`James-Yu.latex-workshop`) for live preview (optional)
- **Windows:** Git for Windows installed. `make` automatically runs recipes through its
  `sh`, so PowerShell/CMD and Git Bash all work.

## Usage

```sh
make image                    # build the toolchain image (once)
make list                     # list projects
make pdf P=overall-survey     # -> projects/overall-survey/build/main.pdf
make watch P=overall-survey   # rebuild on save
make all                      # build every project
make new P=my-report          # scaffold a new project from templates/report
make clean                    # remove all build output
```

In VSCode: open any `.tex` file in a project and save — LaTeX Workshop builds that
project's `main.tex` in Docker and shows the PDF in a tab.

## Conventions

- Entry point is always `projects/<name>/main.tex`.
- Keep paths relative to the project folder; don't reference files in other projects
  (Docker and LaTeX Workshop only mount the project folder).
- Compile with XeLaTeX — pdflatex fails on Vietnamese characters.

## Troubleshooting

### `make image` fails at "exporting to image" with `UtimesNanoAt ... no such file or directory`

Intermittent containerd bug while extracting layers (containerd#14309, fixed upstream in
Oct 2026; Docker Desktop may still bundle the affected version). The previous image is usually
intact — check with `docker images specialized-latex`, then just retry:

```sh
docker builder prune -af     # drop the half-written cache
# restart Docker Desktop, then
make image
```

If Docker's disk image sits on a nearly full drive, move it: **Settings → Resources → Advanced →
Disk image location** (keep ≥ 10 GB free).

### `'test' is not recognized ...` / `'{' is not recognized ...`

Make was using `cmd.exe` instead of a POSIX shell. The `Makefile` now points `SHELL` at
Git for Windows' `sh`; pull the current `Makefile`, or force it:

```sh
make SHELL="C:/Program Files/Git/bin/sh.exe" pdf P=overall-survey
```

### `docker: ... the working directory 'C:/Program Files/Git/data' is invalid`

Git Bash rewrote `-w /data` into a Windows path. The `Makefile` already sets
`MSYS_NO_PATHCONV=1`; if you invoke `docker run` yourself, set it too.

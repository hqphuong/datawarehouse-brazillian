# Báo cáo BTL CO4031 – HK261 (LaTeX)
Biên dịch bằng **XeLaTeX** (Overleaf: Menu → Compiler → XeLaTeX):
    latexmk -xelatex main.tex
- Thông tin nhóm: sửa `main.tex` (\groupname) và `sections/00_cover.tex`; tìm `TODO` (chữ đỏ) để điền.
- Logo: đặt `images/logo_bk.png` (tự hiện lên bìa).
- Hình: `images/mapping.png`, `images/star_schema_only.png`, `images/layouts.png`.

# Ghi chú các chỗ cần nhóm tự điền / xác nhận

Trong báo cáo, ô cần điền có dạng **[MÃ]** (chữ đỏ), chỗ cần viết thêm có dạng **[TODO: ...]**. Tìm bằng `\fillin` và `\todo` trong `sections/`.

## 1. Thông số cần điền (tính từ dữ liệu)
| Mã | Vị trí | Nội dung | Cách lấy (gợi ý) |
|---|---|---|---|
| N1–N9 | Bảng 3.1 (`03_du_lieu_nguon.tex`) | Số dòng 9 bảng nguồn | `len(pd.read_csv(file))` hoặc `SELECT COUNT(*)` |
| N10 | Mục 3.1 | Khoảng thời gian dữ liệu | min/max của `order_purchase_timestamp` |
| W1 | Mục 4.2 (Dim_Product) | Ngưỡng phân nhóm `weight_category` | theo code ETL của nhóm |
| P1 | Bảng 3.5 (chất lượng dữ liệu) | Quy tắc chọn `payment_type` khi 1 đơn có nhiều phương thức | theo code ETL |
| R1 | Bảng 3.5 | Quy tắc chọn review khi 1 đơn có nhiều review | theo code ETL |
| L1–L4 | Bảng "Quy mô kho dữ liệu" (mục 4.5) | Số dòng Fact, Dim_Product, Dim_Time, Dim_Location sau ETL | `SELECT COUNT(*)` trên DW |
| Q1 | Cùng bảng | Số dòng nguồn bị loại khi làm sạch | log ETL |

## 2. Nội dung do mình soạn, cần nhóm xác nhận khớp với code thực tế
- Bảng 3.5 (quy tắc làm sạch): gộp geolocation theo zip, chuẩn hoá tên thành phố, thành viên Unknown, chỉ nạp đơn `delivered`, loại khoảng thời gian âm, gán `unknown` cho danh mục thiếu.
- Mục 4.2: SCD Type 1, khoá thay thế `time_id` dạng yyyymmdd, `volume_cm3` = dài × cao × rộng.
- Mục 4.4 (ETL): ba bước Extract, Transform, Load và bước kiểm tra ràng buộc.
- Mục 5.2.1: quy tắc cảnh báo (ngưỡng vượt trong k kỳ liên tiếp) và cách xác định nguyên nhân gốc.
- Phụ lục (DDL): kiểu dữ liệu và cú pháp.

## 3. Lưu ý về schema hiện tại
Fact hiện không có `seller_id`, `delay_days` (hoặc ngày giao dự kiến) và `price`. Vì vậy mục What-if (5.2) mình để **[TODO]** cho công thức tính lại `is_late`, nhóm cần quyết định cách tính (ví dụ thêm `delay_days`, hoặc dùng giả định khác). Nếu sửa schema, cập nhật lại Chương 4 và Phụ lục.

## 4. Các chương để trống (nhóm viết sau)
- Chương 6: Hiện thực hệ thống (kiến trúc, ETL, CSDL/OLAP, 4 giao diện kèm ảnh chụp màn hình).
- Chương 7: Đánh giá, hạn chế, hướng phát triển.
- Chương 8: cột "Minh chứng" đã trỏ tới Chương 6; kiểm tra lại sau khi viết xong.

## 5. Thông tin chung
- Bìa: tên nhóm (`\groupname` trong `main.tex`), thành viên trong `sections/00_cover.tex`, link GitHub/video; logo Bách Khoa đã có sẵn tại `images/hcmut.png`.
- Trang "Danh sách thành viên & Phân công": `sections/00b_phan_cong.tex`.
- Ảnh mapping không màu: thay file **`images/mapping.png`** (giữ nguyên tên). Ảnh star schema: `images/star_schema_only.png`; ảnh layout: `images/layouts.png`.
